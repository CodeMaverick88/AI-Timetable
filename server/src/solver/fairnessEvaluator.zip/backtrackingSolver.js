// @ts-nocheck
const { checkAssignment, slotLabel } = require("./constraintChecker");
const {
  collectConflictedIds,
  detectConflicts,
} = require("./conflictDetector");
const {
  buildUnaryDomain,
  sortCandidates,
} = require("./constraintPropagation");
const { rankCandidates } = require("./costFunction");
const { rankCandidatesByFairness } = require("./fairnessEvaluator");

function cloneEntries(entries) {
  return entries.map((entry) => ({
    ...entry,
    course: entry.course ? { ...entry.course } : entry.course,
    lecturer: entry.lecturer ? { ...entry.lecturer } : entry.lecturer,
    venue: entry.venue ? { ...entry.venue } : entry.venue,
    studentGroup: entry.studentGroup ? { ...entry.studentGroup } : entry.studentGroup,
    timeSlot: entry.timeSlot ? { ...entry.timeSlot } : entry.timeSlot,
  }));
}

function applyCandidate(entry, candidate) {
  return {
    ...entry,
    timeSlot: candidate.timeSlot,
    venue: candidate.venue,
    timeSlotId: candidate.timeSlot.id,
    venueId: candidate.venue ? candidate.venue.id : null,
  };
}

function unassign(entry) {
  return {
    ...entry,
    timeSlot: null,
    venue: null,
    timeSlotId: null,
    venueId: null,
  };
}

function rankedDomain({ entry, domain, workingEntries }) {
  const valid = domain.filter(
    (candidate) =>
      checkAssignment({
        entry,
        proposedTimeSlot: candidate.timeSlot,
        proposedVenue: candidate.venue,
        allEntries: workingEntries,
      }).valid
  );
  if (valid.length === 0) return [];

  const costRanked = rankCandidates({
    entry,
    candidates: valid,
    allEntries: workingEntries,
  });

  return rankCandidatesByFairness({
    entry,
    candidates: costRanked,
    allEntries: workingEntries,
  }).sort((a, b) => {
    const aScore = (a.cost || 0) + (a.fairnessPenalty || 0);
    const bScore = (b.cost || 0) + (b.fairnessPenalty || 0);
    return aScore - bScore;
  });
}

function createAction({ original, next, actionOrder, cost, fairnessPenalty }) {
  const timeChanged = original.timeSlotId !== next.timeSlotId;
  const venueChanged = original.venueId !== next.venueId;
  let actionType = "REASSIGN";
  if (timeChanged && !venueChanged) actionType = "MOVE_TIME";
  else if (!timeChanged && venueChanged) actionType = "MOVE_VENUE";
  else if (timeChanged && venueChanged) actionType = "COMBINATION";

  const reasons = [];
  if (timeChanged) reasons.push(`moved to ${slotLabel(next.timeSlot)}`);
  if (venueChanged) {
    reasons.push(
      next.venue ? `assigned ${next.venue.name}` : "removed the physical venue"
    );
  }

  return {
    timetableEntryId: original.id,
    actionType,
    fromTimeSlotId: original.timeSlotId,
    toTimeSlotId: next.timeSlotId,
    fromVenueId: original.venueId,
    toVenueId: next.venueId,
    cost: Number(cost.toFixed(2)),
    fairnessPenalty: Number(fairnessPenalty.toFixed(2)),
    valid: true,
    rejectionReason: null,
    reasoning:
      `ORBIT selected this assignment because it satisfies lecturer, venue, student-group, ` +
      `and university-hour constraints while minimizing disruption. ` +
      `${reasons.join(" and ") || "kept the existing assignment"}.`,
    actionOrder,
  };
}

function buildActions(original, solved) {
  const originalMap = new Map(original.map((entry) => [entry.id, entry]));
  const actions = [];
  let order = 1;
  for (const entry of solved) {
    const before = originalMap.get(entry.id);
    if (!before) continue;
    if (before.timeSlotId === entry.timeSlotId && before.venueId === entry.venueId) {
      continue;
    }
    actions.push(
      createAction({
        original: before,
        next: entry,
        actionOrder: order,
        cost:
          (before.timeSlotId === entry.timeSlotId ? 0 : 1) +
          (before.venueId === entry.venueId ? 0 : 1),
        fairnessPenalty: 0,
      })
    );
    order += 1;
  }
  return actions;
}

function searchRepair({ original, movable, timeSlots, venues, maxNodes }) {
  const domains = new Map();
  for (const entry of original) {
    if (!movable.has(entry.id)) continue;
    domains.set(
      entry.id,
      sortCandidates(buildUnaryDomain({ entry, timeSlots, venues }), {
        timeSlot: entry.timeSlot,
        venue: entry.venue,
      })
    );
  }

  const working = original.map((entry) =>
    movable.has(entry.id) ? unassign(entry) : { ...entry }
  );

  let nodesVisited = 0;
  let backtracks = 0;

  function selectEntry() {
    const unassigned = working.filter(
      (entry) => movable.has(entry.id) && !entry.timeSlot
    );
    if (unassigned.length === 0) return null;
    let selected = unassigned[0];
    let smallest = Infinity;
    for (const entry of unassigned) {
      const size = rankedDomain({
        entry,
        domain: domains.get(entry.id) || [],
        workingEntries: working,
      }).length;
      if (size < smallest) {
        smallest = size;
        selected = entry;
      }
    }
    return selected;
  }

  function search() {
    nodesVisited += 1;
    if (nodesVisited > maxNodes) return false;
    const entry = selectEntry();
    if (!entry) return detectConflicts(working).length === 0;
    const originalEntry =
      original.find((item) => item.id === entry.id) || entry;
    const candidates = rankedDomain({
      entry: originalEntry,
      domain: domains.get(entry.id) || [],
      workingEntries: working,
    });
    if (candidates.length === 0) return false;
    const index = working.findIndex((item) => item.id === entry.id);
    for (const candidate of candidates) {
      working[index] = applyCandidate(originalEntry, candidate);
      if (search()) return true;
      backtracks += 1;
      working[index] = unassign(originalEntry);
    }
    return false;
  }

  const solved = search();
  return {
    solved,
    entries: cloneEntries(working),
    nodesVisited,
    backtracks,
  };
}

function pickBlocker({ original, movable, timeSlots, venues }) {
  const frozen = original.filter(
    (entry) => !movable.has(entry.id) && entry.timeSlot
  );
  const scores = new Map();

  for (const entry of original) {
    if (!movable.has(entry.id)) continue;
    const domain = buildUnaryDomain({ entry, timeSlots, venues });
    const working = original.map((item) =>
      movable.has(item.id) ? unassign(item) : item
    );
    const free = domain.filter(
      (candidate) =>
        checkAssignment({
          entry,
          proposedTimeSlot: candidate.timeSlot,
          proposedVenue: candidate.venue,
          allEntries: working,
        }).valid
    );
    if (free.length > 0) continue;
    for (const candidate of domain.slice(0, 12)) {
      for (const blocker of frozen) {
        const clash = checkAssignment({
          entry,
          proposedTimeSlot: candidate.timeSlot,
          proposedVenue: candidate.venue,
          allEntries: [blocker],
        });
        if (!clash.valid) {
          scores.set(blocker.id, (scores.get(blocker.id) || 0) + 1);
        }
      }
    }
  }

  let best = null;
  let bestScore = 0;
  for (const [id, score] of scores) {
    if (score > bestScore) {
      best = id;
      bestScore = score;
    }
  }
  return best;
}

function minConflicts({ original, timeSlots, venues, maxIterations }) {
  const working = cloneEntries(original);
  let nodesVisited = 0;

  for (let iteration = 0; iteration < maxIterations; iteration += 1) {
    const conflicts = detectConflicts(working);
    if (conflicts.length === 0) {
      return { solved: true, entries: working, nodesVisited, backtracks: 0 };
    }
    const counts = new Map();
    for (const conflict of conflicts) {
      counts.set(
        conflict.timetableEntryId,
        (counts.get(conflict.timetableEntryId) || 0) + 1
      );
      const other = conflict.metadata && conflict.metadata.conflictingEntryId;
      if (other) counts.set(other, (counts.get(other) || 0) + 1);
    }
    const targetId = [...counts.entries()].sort((a, b) => b[1] - a[1])[0];
    if (!targetId) break;
    const index = working.findIndex((entry) => entry.id === targetId[0]);
    const entry = working[index];
    const domain = buildUnaryDomain({ entry, timeSlots, venues });
    if (domain.length === 0) continue;
    let best = {
      candidate: { timeSlot: entry.timeSlot, venue: entry.venue },
      score: conflicts.length,
    };
    for (const candidate of domain) {
      nodesVisited += 1;
      const snapshot = working[index];
      working[index] = applyCandidate(entry, candidate);
      const score = detectConflicts(working).length;
      if (score < best.score) best = { candidate, score };
      working[index] = snapshot;
    }
    if (best.candidate && best.candidate.timeSlot) {
      working[index] = applyCandidate(entry, best.candidate);
    }
  }

  const remaining = detectConflicts(working);
  return {
    solved: remaining.length === 0,
    entries: working,
    nodesVisited,
    backtracks: 0,
  };
}

function solveWithBacktracking({
  entries,
  timeSlots,
  venues,
  maxNodes = 25000,
}) {
  const original = cloneEntries(entries);
  const initialConflicts = detectConflicts(original);
  const movable = collectConflictedIds(initialConflicts);

  if (movable.size === 0) {
    return {
      solved: true,
      entries: original,
      actions: [],
      stats: {
        nodesVisited: 0,
        backtracks: 0,
        maxNodes,
        actionsCreated: 0,
        strategy: "already-valid",
        movableCount: 0,
      },
    };
  }

  let nodesVisited = 0;
  let backtracks = 0;
  let strategy = "repair";
  let result = searchRepair({
    original,
    movable: new Set(movable),
    timeSlots,
    venues,
    maxNodes,
  });
  nodesVisited += result.nodesVisited;
  backtracks += result.backtracks;

  if (!result.solved || detectConflicts(result.entries).length > 0) {
    const expanding = new Set(movable);
    for (let step = 0; step < 10; step += 1) {
      const blocker = pickBlocker({
        original,
        movable: expanding,
        timeSlots,
        venues,
      });
      if (!blocker) break;
      expanding.add(blocker);
      result = searchRepair({
        original,
        movable: expanding,
        timeSlots,
        venues,
        maxNodes,
      });
      nodesVisited += result.nodesVisited;
      backtracks += result.backtracks;
      strategy = "repair+expand";
      if (result.solved && detectConflicts(result.entries).length === 0) break;
    }
  }

  if (!result.solved || detectConflicts(result.entries).length > 0) {
    const local = minConflicts({
      original,
      timeSlots,
      venues,
      maxIterations: 1500,
    });
    nodesVisited += local.nodesVisited;
    if (local.solved) {
      result = local;
      strategy = "min-conflicts";
    }
  }

  const remaining = detectConflicts(result.entries);
  const solved = remaining.length === 0;
  const actions = solved ? buildActions(original, result.entries) : [];

  return {
    solved,
    entries: result.entries,
    actions,
    stats: {
      nodesVisited,
      backtracks,
      maxNodes,
      actionsCreated: actions.length,
      strategy,
      movableCount: movable.size,
    },
  };
}

module.exports = {
  solveWithBacktracking,
};