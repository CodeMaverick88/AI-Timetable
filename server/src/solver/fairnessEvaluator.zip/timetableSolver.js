// @ts-nocheck
const prisma = require("../lib/prisma");
const { solveWithBacktracking } = require("./backtrackingSolver");
const { calculateFairnessScore } = require("./fairnessEvaluator");
const { detectConflicts } = require("./conflictDetector");
const { propagateEntries, summarizePropagation } = require("./constraintPropagation");

async function loadSolverData() {
  const [entries, timeSlots, venues] = await Promise.all([
    prisma.timetableEntry.findMany({
      where: { status: "ACTIVE" },
      include: {
        course: true,
        lecturer: { include: { availabilities: true } },
        venue: { include: { availabilities: true } },
        studentGroup: true,
        timeSlot: true,
      },
      orderBy: { createdAt: "asc" },
    }),
    prisma.timeSlot.findMany({
      where: { active: true },
      orderBy: { sortOrder: "asc" },
    }),
    prisma.venue.findMany({
      where: { active: true },
      orderBy: { code: "asc" },
      include: { availabilities: true },
    }),
  ]);

  return { entries, timeSlots, venues };
}

async function calculateConflictCount() {
  return prisma.conflict.count({
    where: { resolved: false },
  });
}

async function runTimetableSolver({
  scenario = "Automatic conflict resolution",
  initialConflictCount = null,
} = {}) {
  const startedAt = Date.now();
  const data = await loadSolverData();
  const detected = detectConflicts(data.entries);
  const actualInitialConflictCount =
    initialConflictCount == null ? detected.length : initialConflictCount;

  const propagationResults = propagateEntries({
    entries: data.entries,
    timeSlots: data.timeSlots,
    venues: data.venues,
  });
  const propagationSummary = summarizePropagation(propagationResults);

  const result = solveWithBacktracking({
    entries: data.entries,
    timeSlots: data.timeSlots,
    venues: data.venues,
    maxNodes: 25000,
  });

  const remaining = detectConflicts(result.entries);
  const solved = remaining.length === 0;
  const durationMs = Date.now() - startedAt;
  const totalCost = result.actions.reduce(
    (sum, action) => sum + Number(action.cost || 0),
    0
  );

  return {
    success: solved,
    scenario,
    status: solved ? "COMPLETED" : "FAILED",
    initialConflictCount: actualInitialConflictCount,
    finalConflictCount: remaining.length,
    totalCost: Number(totalCost.toFixed(2)),
    fairnessScore: calculateFairnessScore({ entries: result.entries }),
    classesMoved: result.actions.length,
    durationMs,
    reasoning: {
      initialConflictCount: actualInitialConflictCount,
      strategy: result.stats.strategy,
      movableCount: result.stats.movableCount,
      propagation: propagationSummary,
      search: {
        solved,
        nodesVisited: result.stats.nodesVisited,
        backtracks: result.stats.backtracks,
        actionsCreated: result.stats.actionsCreated,
      },
    },
    entries: result.entries,
    actions: result.actions,
    stats: result.stats,
    remainingConflicts: remaining,
    timeSlots: data.timeSlots,
    venues: data.venues,
    propagation: propagationSummary,
  };
}

module.exports = {
  loadSolverData,
  calculateConflictCount,
  runTimetableSolver,
};
