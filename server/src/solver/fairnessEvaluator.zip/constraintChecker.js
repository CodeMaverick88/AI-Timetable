// @ts-nocheck
function timeToMinutes(time) {
  if (time == null) return Number.NaN;
  if (typeof time === "number" && Number.isFinite(time)) return time;
  if (time instanceof Date && !Number.isNaN(time.getTime())) {
    return time.getUTCHours() * 60 + time.getUTCMinutes();
  }

  const raw = String(time).trim();
  const iso = raw.match(/T(\d{2}):(\d{2})/);
  if (iso) return Number(iso[1]) * 60 + Number(iso[2]);
  const match = raw.match(/(\d{1,2}):(\d{2})/);
  if (!match) return Number.NaN;
  return Number(match[1]) * 60 + Number(match[2]);
}

function formatTime(time) {
  const minutes = timeToMinutes(time);
  if (!Number.isFinite(minutes)) return "";
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  return `${String(hours).padStart(2, "0")}:${String(mins).padStart(2, "0")}`;
}

function normalizeDay(value) {
  if (value == null) return null;
  if (typeof value === "number") {
    const map = {
      0: "MONDAY",
      1: "MONDAY",
      2: "TUESDAY",
      3: "WEDNESDAY",
      4: "THURSDAY",
      5: "FRIDAY",
    };
    return map[value] || null;
  }
  const raw = String(value).trim().toUpperCase();
  if (
    ["MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY"].includes(raw)
  ) {
    return raw;
  }
  return null;
}

function slotsOverlap(slotA, slotB) {
  if (!slotA || !slotB) return false;
  const dayA = normalizeDay(slotA.dayOfWeek ?? slotA.day ?? slotA.dayName);
  const dayB = normalizeDay(slotB.dayOfWeek ?? slotB.day ?? slotB.dayName);
  if (!dayA || !dayB || dayA !== dayB) return false;
  const startA = timeToMinutes(slotA.startTime);
  const endA = timeToMinutes(slotA.endTime);
  const startB = timeToMinutes(slotB.startTime);
  const endB = timeToMinutes(slotB.endTime);
  if (![startA, endA, startB, endB].every(Number.isFinite)) return false;
  return startA < endB && startB < endA;
}

function availabilityCoversSlot(availability, timeSlot) {
  if (!availability || availability.available === false) return false;
  const availDay = normalizeDay(availability.dayOfWeek);
  const slotDay = normalizeDay(
    timeSlot.dayOfWeek ?? timeSlot.day ?? timeSlot.dayName
  );
  if (!availDay || !slotDay || availDay !== slotDay) return false;
  return (
    timeToMinutes(availability.startTime) <= timeToMinutes(timeSlot.startTime) &&
    timeToMinutes(availability.endTime) >= timeToMinutes(timeSlot.endTime)
  );
}

function isUniversitySlot(slot) {
  if (!slot || slot.active === false) return false;
  const day = normalizeDay(slot.dayOfWeek ?? slot.day ?? slot.dayName);
  if (!day) return false;
  const start = timeToMinutes(slot.startTime);
  const end = timeToMinutes(slot.endTime);
  if (!Number.isFinite(start) || !Number.isFinite(end) || end <= start) {
    return false;
  }
  return start >= 8 * 60 && end <= 18 * 60;
}

function slotLabel(slot) {
  if (!slot) return "unassigned";
  if (slot.label) return slot.label;
  const day = normalizeDay(slot.dayOfWeek ?? slot.dayName) || "Day";
  return `${day.charAt(0) + day.slice(1).toLowerCase()} ${formatTime(slot.startTime)}–${formatTime(slot.endTime)}`;
}

function checkLecturerAvailability(lecturer, timeSlot) {
  const availabilities = lecturer?.availabilities || [];
  const sameDay = availabilities.filter((availability) => {
    return normalizeDay(availability.dayOfWeek) === normalizeDay(timeSlot.dayOfWeek);
  });
  if (sameDay.length === 0) return { valid: true, reason: null };
  const available = sameDay.some((availability) =>
    availabilityCoversSlot(availability, timeSlot)
  );
  return {
    valid: available,
    reason: available
      ? null
      : `${lecturer?.name || "Lecturer"} is unavailable during ${slotLabel(timeSlot)}.`,
  };
}

function checkVenueAvailability(venue, timeSlot) {
  if (!venue) return { valid: true, reason: null };
  const availabilities = venue.availabilities || [];
  const sameDay = availabilities.filter(
    (availability) =>
      normalizeDay(availability.dayOfWeek) === normalizeDay(timeSlot.dayOfWeek)
  );
  if (sameDay.length === 0) return { valid: true, reason: null };
  const available = sameDay.some((availability) =>
    availabilityCoversSlot(availability, timeSlot)
  );
  return {
    valid: available,
    reason: available
      ? null
      : `${venue.name} is unavailable during ${slotLabel(timeSlot)}.`,
  };
}

function checkVenueRequirements(entry, venue) {
  if (!venue) {
    if (entry.deliveryMode === "ONLINE") return { valid: true, reason: null };
    return { valid: false, type: "MISSING_VENUE", reason: "A physical class requires a venue." };
  }
  if (entry.expectedStudents > venue.capacity) {
    return {
      valid: false,
      type: "VENUE_CAPACITY",
      reason: `${venue.name} has capacity for ${venue.capacity}, but ${entry.expectedStudents} students are expected.`,
    };
  }
  if (entry.requiresComputers && !venue.hasComputers) {
    return {
      valid: false,
      type: "MODE_VENUE_MISMATCH",
      reason: `${entry.course?.name || "This class"} requires computers, but ${venue.name} does not have them.`,
    };
  }
  if (entry.requiresProjector && !venue.hasProjector) {
    return {
      valid: false,
      type: "MODE_VENUE_MISMATCH",
      reason: `${entry.course?.name || "This class"} requires a projector, but ${venue.name} does not have one.`,
    };
  }
  if (entry.deliveryMode === "ONLINE" && !venue.supportsOnline) {
    return {
      valid: false,
      type: "ONLINE_PHYSICAL_CLASH",
      reason: `${entry.course?.name || "This class"} is online, but ${venue.name} does not support online delivery.`,
    };
  }
  return { valid: true, reason: null };
}

function checkUnaryConstraints(entry, timeSlot, venue) {
  const violations = [];
  if (!isUniversitySlot(timeSlot)) {
    violations.push({
      type: "OUTSIDE_UNIVERSITY_HOURS",
      reason: `${slotLabel(timeSlot)} is outside university hours (Monday–Friday, 08:00–18:00).`,
    });
  }
  const lecturerAvailability = checkLecturerAvailability(entry.lecturer, timeSlot);
  if (!lecturerAvailability.valid) {
    violations.push({
      type: "LECTURER_UNAVAILABLE",
      reason: lecturerAvailability.reason,
    });
  }
  const venueAvailability = checkVenueAvailability(venue, timeSlot);
  if (!venueAvailability.valid) {
    violations.push({
      type: "VENUE_UNAVAILABLE",
      reason: venueAvailability.reason,
    });
  }
  const venueRequirements = checkVenueRequirements(entry, venue);
  if (!venueRequirements.valid) {
    violations.push({
      type: venueRequirements.type || "MODE_VENUE_MISMATCH",
      reason: venueRequirements.reason,
    });
  }
  return { valid: violations.length === 0, violations };
}

function checkResourceConflicts({
  entry,
  proposedTimeSlot,
  proposedVenue,
  allEntries,
}) {
  const conflicts = [];
  for (const other of allEntries) {
    if (other.id === entry.id) continue;
    if (other.status && other.status !== "ACTIVE") continue;
    if (!other.timeSlot) continue;
    if (!slotsOverlap(proposedTimeSlot, other.timeSlot)) continue;

    if (entry.lecturerId && other.lecturerId && entry.lecturerId === other.lecturerId) {
      conflicts.push({
        type: "LECTURER_DOUBLE_BOOKING",
        reason:
          `${entry.lecturer?.name || "Lecturer"} is already assigned to ` +
          `${other.course?.code || other.courseId} during ${slotLabel(other.timeSlot)}.`,
        conflictingEntryId: other.id,
      });
    }

    if (proposedVenue && other.venueId && proposedVenue.id === other.venueId) {
      conflicts.push({
        type: "VENUE_DOUBLE_BOOKING",
        reason:
          `${proposedVenue.name} is already assigned to ` +
          `${other.course?.code || other.courseId} during ${slotLabel(other.timeSlot)}.`,
        conflictingEntryId: other.id,
      });
    }

    if (
      entry.studentGroupId &&
      other.studentGroupId &&
      entry.studentGroupId === other.studentGroupId
    ) {
      conflicts.push({
        type: "STUDENT_GROUP_CLASH",
        reason:
          `${entry.studentGroup?.name || "Student group"} already has ` +
          `${other.course?.code || other.courseId} during ${slotLabel(other.timeSlot)}.`,
        conflictingEntryId: other.id,
      });
    }
  }
  return conflicts;
}

function checkAssignment({
  entry,
  proposedTimeSlot,
  proposedVenue,
  allEntries,
}) {
  if (!entry) {
    return {
      valid: false,
      violations: [{ type: "INVALID_ENTRY", reason: "Timetable entry was not provided." }],
    };
  }
  if (!proposedTimeSlot) {
    return {
      valid: false,
      violations: [{ type: "INVALID_TIME_SLOT", reason: "A time slot must be provided." }],
    };
  }
  const unary = checkUnaryConstraints(entry, proposedTimeSlot, proposedVenue || null);
  const resourceConflicts = checkResourceConflicts({
    entry,
    proposedTimeSlot,
    proposedVenue: proposedVenue || null,
    allEntries,
  });
  const violations = unary.violations.concat(resourceConflicts);
  return { valid: violations.length === 0, violations };
}

module.exports = {
  timeToMinutes,
  formatTime,
  normalizeDay,
  slotsOverlap,
  availabilityCoversSlot,
  isUniversitySlot,
  slotLabel,
  checkLecturerAvailability,
  checkVenueAvailability,
  checkVenueRequirements,
  checkUnaryConstraints,
  checkResourceConflicts,
  checkAssignment,
};