```jsx
import { motion } from "framer-motion";
import {
  ArrowRight,
  BrainCircuit,
  CalendarDays,
} from "lucide-react";
import { Link } from "react-router-dom";

export default function Hero() {
  return (
    <section className="hero">
      <div className="hero-copy">
        <motion.div
          className="hero-label"
          initial={{
            opacity: 0,
            y: 10,
          }}
          animate={{
            opacity: 1,
            y: 0,
          }}
          transition={{
            duration: 0.4,
          }}
        >
          <span />
          SmartTimetable AI
        </motion.div>

        <motion.h1
          initial={{
            opacity: 0,
            y: 16,
          }}
          animate={{
            opacity: 1,
            y: 0,
          }}
          transition={{
            delay: 0.05,
            duration: 0.5,
          }}
        >
          Timetable
          <em>
            {" "}
            control center.
          </em>
        </motion.h1>

        <motion.p
          initial={{
            opacity: 0,
            y: 12,
          }}
          animate={{
            opacity: 1,
            y: 0,
          }}
          transition={{
            delay: 0.1,
            duration: 0.45,
          }}
        >
          View the schedule, create a clash,
          and let ORBIT resolve it.
        </motion.p>

        <motion.div
          className="hero-actions"
          initial={{
            opacity: 0,
            y: 12,
          }}
          animate={{
            opacity: 1,
            y: 0,
          }}
          transition={{
            delay: 0.16,
            duration: 0.45,
          }}
        >
          <Link
            className="button-primary"
            to="/timetable"
          >
            <CalendarDays size={16} />
            View timetable
            <ArrowRight size={15} />
          </Link>

          <Link
            className="button-secondary"
            to="/solver"
          >
            <BrainCircuit size={16} />
            ORBIT
          </Link>
        </motion.div>
      </div>

      <motion.div
        className="hero-orbit"
        initial={{
          opacity: 0,
          scale: 0.9,
        }}
        animate={{
          opacity: 1,
          scale: 1,
        }}
        transition={{
          duration: 0.65,
          ease: [
            0.22,
            1,
            0.36,
            1,
          ],
        }}
      >
        <div className="orbit-circle orbit-circle-one" />
        <div className="orbit-circle orbit-circle-two" />

        <motion.div
          className="orbit-core"
          animate={{
            y: [0, -5, 0],
          }}
          transition={{
            duration: 3.5,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        >
          <BrainCircuit size={38} />

          <strong>
            ORBIT
          </strong>

          <span>
            AI SOLVER
          </span>
        </motion.div>

        <motion.div
          className="orbit-point point-one"
          animate={{
            rotate: 360,
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: "linear",
          }}
        />

        <motion.div
          className="orbit-point point-two"
          animate={{
            rotate: -360,
          }}
          transition={{
            duration: 13,
            repeat: Infinity,
            ease: "linear",
          }}
        />

        <div className="orbit-point point-three" />
      </motion.div>
    </section>
  );
}
```
