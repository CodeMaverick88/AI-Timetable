import { useCallback, useEffect, useRef, useState } from "react";
import {
  AlertTriangle,
  ArrowRight,
  BrainCircuit,
  CheckCircle2,
  Pause,
  Play,
  RefreshCw,
  RotateCcw,
  Zap,
  XCircle,
} from "lucide-react";
import { Link } from "react-router-dom";

import Reveal from "../components/Reveal";
import GlassCard from "../components/GlassCard";
import TimetableBoard from "../components/TimetableBoard";

import {
  getConflicts,
  getTimetable,
} from "../services/api";

const API =
  import.meta.env.VITE_API_URL ||
  "http://localhost:5000";

const STAGES = [
  "detect",
  "propagate",
  "search",
  "verify",
];

export default function Solver() {
  const [entries, setEntries] = useState([]);
  const [conflicts, setConflicts] = useState([]);

  const [loading, setLoading] = useState(true);
  const [running, setRunning] = useState(false);
  const [paused, setPaused] = useState(false);

  const [stage, setStage] = useState("idle");
  const [status, setStatus] = useState("Ready");

  const [actions, setActions] = useState([]);
  const [currentActionIndex, setCurrentActionIndex] =
    useState(-1);

  const [activeEntryId, setActiveEntryId] =
    useState(null);

  const [movedEntryIds, setMovedEntryIds] =
    useState([]);

  const [reasoning, setReasoning] = useState(
    "ORBIT is ready.",
  );

  const [solverResult, setSolverResult] =
    useState(null);

  const [error, setError] = useState("");

  const [originalEntries, setOriginalEntries] =
    useState([]);

  const pausedRef = useRef(false);
  const stopRef = useRef(false);

  const currentAction =
    currentActionIndex >= 0
      ? actions[currentActionIndex]
      : null;

  const completedActions =
    currentActionIndex >= 0
      ? currentActionIndex + 1
      : 0;

  const totalActions = actions.length;

  const progress =
    totalActions > 0
      ? Math.round(
          (completedActions / totalActions) * 100,
        )
      : 0;

  useEffect(() => {
    pausedRef.current = paused;
  }, [paused]);

  const loadTimetable = useCallback(async () => {
    const [
      timetable,
      conflictData,
    ] = await Promise.all([
      getTimetable(),
      getConflicts(),
    ]);

    const loadedEntries =
      timetable.entries || [];

    const loadedConflicts =
      conflictData.conflicts || [];

    setEntries(loadedEntries);
    setConflicts(loadedConflicts);

    return {
      entries: loadedEntries,
      conflicts: loadedConflicts,
    };
  }, []);

  useEffect(() => {
    async function load() {
      try {
        await loadTimetable();
      } catch (loadError) {
        console.error(loadError);

        setError(
          loadError.message ||
            "Unable to load timetable.",
        );
      } finally {
        setLoading(false);
      }
    }

    load();
  }, [loadTimetable]);

  async function request(path, options = {}) {
    const response = await fetch(
      `${API}${path}`,
      {
        ...options,
        headers: {
          "Content-Type":
            "application/json",
          ...(options.headers || {}),
        },
      },
    );

    const data =
      await response.json().catch(
        () => ({}),
      );

    if (!response.ok) {
      throw new Error(
        data.message ||
          "ORBIT request failed.",
      );
    }

    return data;
  }

  async function detectConflicts() {
    setStage("detect");
    setStatus("Detecting conflicts");
    setReasoning(
      "Scanning the timetable for lecturer, venue, student-group and availability conflicts.",
    );

    const data = await request(
      "/api/conflicts/detect",
      {
        method: "POST",
      },
    );

    setConflicts(
      data.conflicts || [],
    );

    return data;
  }

  async function runSolver() {
    if (running) {
      return;
    }

    setError("");
    setRunning(true);
    setPaused(false);

    pausedRef.current = false;
    stopRef.current = false;

    setSolverResult(null);
    setActions([]);
    setCurrentActionIndex(-1);
    setActiveEntryId(null);
    setMovedEntryIds([]);

    try {
      /*
       * IMPORTANT:
       * Capture the timetable before the backend solver
       * changes the database.
       */
      const initialData =
        await loadTimetable();

      const snapshot =
        cloneEntries(
          initialData.entries,
        );

      setOriginalEntries(snapshot);

      /*
       * 1. DETECT
       */
      await detectConflicts();

      if (stopRef.current) {
        return;
      }

      /*
       * 2. PROPAGATE
       *
       * The actual propagation happens inside the
       * backend solver. This short pause simply gives
       * the user time to see the stage transition.
       */
      setStage("propagate");
      setStatus("Propagating constraints");
      setReasoning(
        "Eliminating timetable choices that cannot satisfy the scheduling constraints.",
      );

      await wait(900);

      if (stopRef.current) {
        return;
      }

      /*
       * 3. SEARCH
       *
       * THIS IS THE REAL SOLVER CALL.
       */
      setStage("search");
      setStatus("ORBIT is solving");
      setReasoning(
        "Searching the constraint space for valid timetable assignments.",
      );

      const result = await request(
        "/api/solver/run",
        {
          method: "POST",
        },
      );

      const solverActions =
        result.actions || [];

      setSolverResult(result);
      setActions(solverActions);

      if (result.status !== "COMPLETED") {
        throw new Error(
          "The ORBIT solver did not complete successfully.",
        );
      }

      /*
       * The backend commits the final timetable before
       * returning the response.
       *
       * Therefore we DO NOT reload the timetable here.
       *
       * Instead, we replay the real actions against
       * the captured BEFORE snapshot.
       */
      if (solverActions.length === 0) {
        setStage("verify");
        setStatus("Verifying");
        setReasoning(
          "ORBIT found no timetable changes were required.",
        );

        await wait(700);

        if (!stopRef.current) {
          await verifyTimetable();
        }

        return;
      }

      await replayRealActions(
        solverActions,
        snapshot,
      );

      if (stopRef.current) {
        setStatus("Run stopped");
        return;
      }

      /*
       * 4. VERIFY
       */
      setStage("verify");
      setStatus("Verifying timetable");
      setReasoning(
        "Checking the solved timetable for remaining conflicts.",
      );

      await wait(700);

      await verifyTimetable();

      if (!stopRef.current) {
        setStatus("Verified");
        setReasoning(
          "ORBIT completed the solve. Verification returned zero active conflicts.",
        );
      }
    } catch (solverError) {
      console.error(solverError);

      setStage("error");
      setStatus("Solver error");

      setError(
        solverError.message ||
          "ORBIT could not complete the solve.",
      );

      setReasoning(
        "The solver stopped before verification.",
      );
    } finally {
      setRunning(false);
      setPaused(false);

      pausedRef.current = false;
      stopRef.current = false;
    }
  }

  async function replayRealActions(
    solverActions,
    beforeEntries,
  ) {
    /*
     * Build lookup maps from the BEFORE timetable.
     *
     * This is important because a slot may no longer
     * be occupied by the original class after an
     * earlier action has been replayed.
     */
    const slotMap = new Map();
    const venueMap = new Map();
    const lecturerMap = new Map();

    beforeEntries.forEach((entry) => {
      if (entry.timeSlot?.id) {
        slotMap.set(
          entry.timeSlot.id,
          entry.timeSlot,
        );
      }

      if (entry.venue?.id) {
        venueMap.set(
          entry.venue.id,
          entry.venue,
        );
      }

      if (entry.lecturer?.id) {
        lecturerMap.set(
          entry.lecturer.id,
          entry.lecturer,
        );
      }
    });

    let projectedEntries =
      cloneEntries(beforeEntries);

    setEntries(
      cloneEntries(projectedEntries),
    );

    for (
      let index = 0;
      index < solverActions.length;
      index += 1
    ) {
      if (stopRef.current) {
        return;
      }

      await waitWhilePaused();

      if (stopRef.current) {
        return;
      }

      const action =
        solverActions[index];

      const entryId =
        action?.timetableEntryId ||
        action?.entryId;

      setCurrentActionIndex(index);
      setActiveEntryId(
        entryId || null,
      );

      if (entryId) {
        setMovedEntryIds(
          (current) =>
            current.includes(entryId)
              ? current
              : [...current, entryId],
        );
      }

      setStatus(
        getActionStatus(
          action?.actionType,
        ),
      );

      setReasoning(
        action?.reasoning ||
          buildActionReasoning(action),
      );

      /*
       * Give the user a moment to see which class
       * ORBIT selected.
       */
      await wait(550);

      if (stopRef.current) {
        return;
      }

      /*
       * Apply the EXACT solver action to our local
       * visual projection.
       */
      projectedEntries =
        applySolverAction(
          projectedEntries,
          action,
          slotMap,
          venueMap,
          lecturerMap,
        );

      /*
       * This state update causes TimetableBoard to
       * receive a different timeSlot / venue.
       *
       * Framer Motion then visibly moves the same
       * timetable card to the new cell.
       */
      setEntries(
        cloneEntries(projectedEntries),
      );

      await waitWhilePaused();

      if (stopRef.current) {
        return;
      }

      /*
       * Leave the move visible long enough for the
       * audience to understand it.
       */
      await wait(1100);
    }

    setActiveEntryId(null);
  }

  async function verifyTimetable() {
    const verification =
      await request(
        "/api/conflicts/detect",
        {
          method: "POST",
        },
      );

    const remaining =
      verification.conflicts || [];

    setConflicts(remaining);

    /*
     * Only reload the database AFTER the visual
     * replay has completed.
     */
    const finalData =
      await loadTimetable();

    /*
     * Keep the actual database result visible.
     */
    setEntries(
      finalData.entries || [],
    );

    if (remaining.length === 0) {
      setStage("verified");
      setStatus("Verified");
      setReasoning(
        "0 active conflicts. The timetable is valid.",
      );
    } else {
      setStage("warning");

      setStatus(
        `${remaining.length} conflict${
          remaining.length === 1
            ? ""
            : "s"
        } remain`,
      );

      setReasoning(
        "Verification found remaining conflicts.",
      );
    }

    return verification;
  }

  async function resetDemo() {
    stopRef.current = true;
    pausedRef.current = false;

    setRunning(false);
    setPaused(false);

    setError("");
    setStage("reset");
    setStatus("Resetting");
    setReasoning(
      "Restoring the original timetable.",
    );

    try {
      await request(
        "/api/demo/reset",
        {
          method: "POST",
        },
      );

      setActions([]);
      setCurrentActionIndex(-1);
      setActiveEntryId(null);
      setMovedEntryIds([]);
      setSolverResult(null);
      setOriginalEntries([]);

      await loadTimetable();

      setStage("idle");
      setStatus("Ready");
      setReasoning(
        "Timetable restored. Create a conflict or run ORBIT.",
      );
    } catch (resetError) {
      console.error(resetError);

      setStage("error");
      setStatus("Reset failed");

      setError(
        resetError.message ||
          "Unable to reset the demo.",
      );
    } finally {
      stopRef.current = false;
    }
  }

  function stopSolver() {
    stopRef.current = true;
    pausedRef.current = false;

    setPaused(false);
    setRunning(false);
    setActiveEntryId(null);

    setStatus("Run stopped");
    setReasoning(
      "ORBIT run stopped.",
    );
  }

  async function replayActions() {
    if (!actions.length || running) {
      return;
    }

    try {
      stopRef.current = false;
      pausedRef.current = false;

      setError("");
      setRunning(true);
      setPaused(false);
      setCurrentActionIndex(-1);
      setActiveEntryId(null);
      setMovedEntryIds([]);

      setStage("search");
      setStatus("Preparing replay");
      setReasoning(
        "Restoring the original timetable before replaying ORBIT's real decisions.",
      );

      /*
       * We reset first because the database was already
       * solved by the previous run.
       */
      await request(
        "/api/demo/reset",
        {
          method: "POST",
        },
      );

      const resetData =
        await loadTimetable();

      const beforeEntries =
        cloneEntries(
          resetData.entries,
        );

      setOriginalEntries(
        beforeEntries,
      );

      /*
       * Generate a fresh real solver action sequence.
       */
      const result = await request(
        "/api/solver/run",
        {
          method: "POST",
        },
      );

      const freshActions =
        result.actions || [];

      setSolverResult(result);
      setActions(freshActions);

      await replayRealActions(
        freshActions,
        beforeEntries,
      );

      if (!stopRef.current) {
        await verifyTimetable();
      }
    } catch (replayError) {
      console.error(replayError);

      setStage("error");
      setStatus("Replay failed");

      setError(
        replayError.message ||
          "Replay could not complete.",
      );
    } finally {
      setRunning(false);
      setPaused(false);

      pausedRef.current = false;
      stopRef.current = false;
    }
  }

  const stageLabel =
    stage === "detect"
      ? "Conflict detection"
      : stage === "propagate"
        ? "Constraint propagation"
        : stage === "search"
          ? "Constraint search"
          : stage === "verify" ||
              stage === "verified"
            ? "Verification"
            : stage === "error"
              ? "Solver error"
              : "System ready";

  return (
    <div className="solver-page">
      <Reveal>
        <div className="page-heading solver-heading">
          <div>
            <span className="eyebrow-small">
              ORBIT
            </span>

            <h1>
              Timetable solver
            </h1>

            <p>
              {status}
            </p>
          </div>

          <div className="solver-heading-actions">
            <button
              className="button-secondary"
              type="button"
              onClick={resetDemo}
              disabled={running}
            >
              <RotateCcw size={15} />
              Reset
            </button>

            {actions.length > 0 &&
              !running && (
                <button
                  className="button-secondary"
                  type="button"
                  onClick={replayActions}
                >
                  <RefreshCw size={15} />
                  Replay
                </button>
              )}
          </div>
        </div>
      </Reveal>

      {error && (
        <Reveal>
          <div className="solver-error">
            <XCircle size={18} />

            <div>
              <strong>
                ORBIT error
              </strong>

              <p>
                {error}
              </p>
            </div>
          </div>
        </Reveal>
      )}

      <Reveal delay={0.04}>
        <div className="solver-stage-strip">
          {STAGES.map((item, index) => {
            const currentIndex =
              STAGES.indexOf(stage);

            const completed =
              stage === "verified" ||
              currentIndex > index;

            const active =
              stage === item;

            return (
              <div
                className={`solver-stage ${
                  active ? "active" : ""
                } ${
                  completed
                    ? "completed"
                    : ""
                }`}
                key={item}
              >
                <span className="solver-stage-number">
                  {completed ? (
                    <CheckCircle2
                      size={14}
                    />
                  ) : (
                    `0${index + 1}`
                  )}
                </span>

                <div>
                  <strong>
                    {getStageName(item)}
                  </strong>
                </div>
              </div>
            );
          })}
        </div>
      </Reveal>

      <div className="solver-layout">
        <Reveal delay={0.08}>
          <GlassCard className="solver-board-card">
            <div className="section-header">
              <div>
                <span className="eyebrow-small">
                  LIVE SCHEDULE
                </span>

                <h2>
                  ORBIT workspace
                </h2>
              </div>

              <div className="solver-board-state">
                <span className="orbit-live-dot" />
                {stageLabel}
              </div>
            </div>

            <TimetableBoard
              entries={entries}
              loading={loading}
              movedEntryIds={
                movedEntryIds
              }
              activeEntryId={
                activeEntryId
              }
              actionEntryId={
                currentAction
                  ?.timetableEntryId ||
                null
              }
            />
          </GlassCard>
        </Reveal>

        <Reveal delay={0.12}>
          <aside className="solver-panel">
            <GlassCard className="orbit-control-card">
              <div className="orbit-control-header">
                <div className="orbit-control-icon">
                  <BrainCircuit
                    size={22}
                  />
                </div>

                <div>
                  <span className="eyebrow-small">
                    ORBIT ENGINE
                  </span>

                  <h2>
                    {status}
                  </h2>
                </div>
              </div>

              <div className="orbit-progress">
                <div className="orbit-progress-label">
                  <span>
                    {totalActions > 0
                      ? `Decision ${Math.min(
                          completedActions,
                          totalActions,
                        )} / ${totalActions}`
                      : "Ready"}
                  </span>

                  <strong>
                    {progress}%
                  </strong>
                </div>

                <div className="orbit-progress-track">
                  <div
                    className="orbit-progress-fill"
                    style={{
                      width: `${progress}%`,
                    }}
                  />
                </div>
              </div>

              <div className="orbit-reasoning">
                <div className="reasoning-icon">
                  <Zap size={17} />
                </div>

                <div>
                  <span>
                    ORBIT ACTIVITY
                  </span>

                  <p>
                    {reasoning}
                  </p>
                </div>
              </div>

              {currentAction && (
                <div className="solver-action">
                  <div className="solver-action-top">
                    <span>
                      CURRENT MOVE
                    </span>

                    <strong>
                      {formatActionType(
                        currentAction.actionType,
                      )}
                    </strong>
                  </div>

                  <div className="solver-action-line">
                    <span>
                      Class
                    </span>

                    <strong>
                      {getActionEntryLabel(
                        currentAction,
                        entries,
                      )}
                    </strong>
                  </div>

                  <div className="solver-action-line">
                    <span>
                      Change
                    </span>

                    <strong>
                      {getActionChangeLabel(
                        currentAction,
                        originalEntries,
                      )}
                    </strong>
                  </div>
                </div>
              )}

              <div className="orbit-controls">
                {!running ? (
                  <button
                    className="button-primary solver-run-button"
                    type="button"
                    onClick={runSolver}
                    disabled={loading}
                  >
                    <Play size={16} />
                    Run ORBIT
                    <ArrowRight
                      size={15}
                    />
                  </button>
                ) : (
                  <>
                    <button
                      className="button-primary solver-run-button"
                      type="button"
                      onClick={() => {
                        const next =
                          !paused;

                        pausedRef.current =
                          next;

                        setPaused(next);

                        setStatus(
                          next
                            ? "ORBIT paused"
                            : "ORBIT is solving",
                        );
                      }}
                    >
                      {paused ? (
                        <>
                          <Play size={16} />
                          Resume
                        </>
                      ) : (
                        <>
                          <Pause size={16} />
                          Pause
                        </>
                      )}
                    </button>

                    <button
                      className="button-secondary"
                      type="button"
                      onClick={stopSolver}
                    >
                      <XCircle size={15} />
                      Stop
                    </button>
                  </>
                )}
              </div>
            </GlassCard>

            <GlassCard className="solver-stats-card">
              <div className="solver-stats-heading">
                <span className="eyebrow-small">
                  RESULTS
                </span>

                <Zap size={17} />
              </div>

              <div className="solver-stats">
                <SolverMetric
                  label="Conflicts"
                  value={
                    solverResult
                      ?.initialConflictCount ??
                    conflicts.length
                  }
                />

                <SolverMetric
                  label="Remaining"
                  value={
                    solverResult
                      ?.finalConflictCount ??
                    "—"
                  }
                />

                <SolverMetric
                  label="Moved"
                  value={
                    solverResult
                      ?.classesMoved ??
                    "—"
                  }
                />

                <SolverMetric
                  label="Nodes"
                  value={
                    solverResult
                      ?.stats
                      ?.nodesVisited ??
                    "—"
                  }
                />
              </div>
            </GlassCard>

            <GlassCard className="solver-verification-card">
              <div className="verification-icon">
                {conflicts.length === 0 ? (
                  <CheckCircle2
                    size={20}
                  />
                ) : (
                  <AlertTriangle
                    size={20}
                  />
                )}
              </div>

              <div>
                <span>
                  VERIFICATION
                </span>

                <strong>
                  {conflicts.length === 0
                    ? "0 conflicts"
                    : `${conflicts.length} active`}
                </strong>
              </div>
            </GlassCard>
          </aside>
        </Reveal>
      </div>

      <Reveal delay={0.16}>
        <section className="solver-bottom">
          <div>
            <span className="eyebrow-small">
              TEST
            </span>

            <h2>
              Create a conflict
            </h2>
          </div>

          <Link
            className="button-secondary"
            to="/conflict-lab"
          >
            Open Conflict Lab
            <ArrowRight size={15} />
          </Link>
        </section>
      </Reveal>
    </div>
  );
}

function applySolverAction(
  entries,
  action,
  slotMap,
  venueMap,
  lecturerMap,
) {
  const entryId =
    action?.timetableEntryId ||
    action?.entryId;

  if (!entryId) {
    return entries;
  }

  const toTime =
    action.toTimeSlotId ??
    action.toSlotId;

  const toVenue =
    action.toVenueId;

  const toLecturer =
    action.toLecturerId;

  return entries.map((entry) => {
    if (entry.id !== entryId) {
      return entry;
    }

    const nextEntry = {
      ...entry,
    };

    if (
      toTime &&
      slotMap.has(toTime)
    ) {
      nextEntry.timeSlot =
        cloneObject(
          slotMap.get(toTime),
        );
    }

    if (
      toVenue &&
      venueMap.has(toVenue)
    ) {
      nextEntry.venue =
        cloneObject(
          venueMap.get(toVenue),
        );
    }

    if (
      toLecturer &&
      lecturerMap.has(toLecturer)
    ) {
      nextEntry.lecturer =
        cloneObject(
          lecturerMap.get(toLecturer),
        );
    }

    return nextEntry;
  });
}

function cloneEntries(entries = []) {
  return entries.map((entry) => ({
    ...entry,

    course: entry.course
      ? { ...entry.course }
      : entry.course,

    lecturer: entry.lecturer
      ? { ...entry.lecturer }
      : entry.lecturer,

    venue: entry.venue
      ? { ...entry.venue }
      : entry.venue,

    studentGroup:
      entry.studentGroup
        ? {
            ...entry.studentGroup,
          }
        : entry.studentGroup,

    timeSlot: entry.timeSlot
      ? { ...entry.timeSlot }
      : entry.timeSlot,
  }));
}

function cloneObject(value) {
  return value
    ? { ...value }
    : value;
}

function SolverMetric({
  label,
  value,
}) {
  return (
    <div className="solver-metric">
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}

function getStageName(stage) {
  const names = {
    detect: "Detect",
    propagate: "Propagate",
    search: "Search",
    verify: "Verify",
  };

  return names[stage] || stage;
}

function formatActionType(type) {
  if (!type) {
    return "DECISION";
  }

  return type
    .replaceAll("_", " ")
    .toLowerCase()
    .replace(
      /\b\w/g,
      (letter) =>
        letter.toUpperCase(),
    );
}

function getActionStatus(type) {
  const labels = {
    ASSIGN: "Assigning class",
    REASSIGN: "Reassigning class",
    SWAP: "Swapping classes",
    MOVE_TIME: "Moving class",
    MOVE_VENUE: "Moving class",
    CHANGE_LECTURER:
      "Changing lecturer",
    CHANGE_MODE:
      "Changing delivery mode",
    COMBINATION:
      "Applying combined move",
  };

  return (
    labels[type] ||
    "Applying solver decision"
  );
}

function buildActionReasoning(action) {
  const explanations = {
    ASSIGN:
      "A valid timetable position was selected.",
    REASSIGN:
      "The conflicting assignment was replaced.",
    SWAP:
      "Two timetable positions were exchanged.",
    MOVE_TIME:
      "The class was moved to a valid time slot.",
    MOVE_VENUE:
      "The class was moved to a compatible venue.",
    CHANGE_LECTURER:
      "The lecturer assignment was changed.",
    CHANGE_MODE:
      "The delivery mode was changed.",
    COMBINATION:
      "Multiple constraints were resolved together.",
  };

  return (
    explanations[
      action?.actionType
    ] ||
    "A valid solver decision was applied."
  );
}

function getActionEntryLabel(
  action,
  entries,
) {
  const id =
    action?.timetableEntryId ||
    action?.entryId;

  const entry =
    entries.find(
      (item) => item.id === id,
    );

  return (
    entry?.course?.code ||
    entry?.course?.name ||
    id ||
    "Current class"
  );
}

function getActionChangeLabel(
  action,
  originalEntries,
) {
  if (!action) {
    return "—";
  }

  const entryId =
    action?.timetableEntryId ||
    action?.entryId;

  const original =
    originalEntries.find(
      (entry) =>
        entry.id === entryId,
    );

  const fromTimeId =
    action.fromTimeSlotId ??
    action.fromSlotId;

  const toTimeId =
    action.toTimeSlotId ??
    action.toSlotId;

  const fromVenueId =
    action.fromVenueId;

  const toVenueId =
    action.toVenueId;

  const parts = [];

  if (
    fromTimeId &&
    toTimeId &&
    original?.timeSlot?.id
  ) {
    const fromLabel =
      original.timeSlot.label ||
      formatSlot(original.timeSlot);

    parts.push(
      `${fromLabel} → destination slot`,
    );
  }

  if (
    fromVenueId &&
    toVenueId
  ) {
    const fromVenue =
      original?.venue?.code ||
      fromVenueId;

    parts.push(
      `${fromVenue} → new venue`,
    );
  }

  if (parts.length > 0) {
    return parts.join(" • ");
  }

  return formatActionType(
    action.actionType,
  );
}

function formatSlot(slot) {
  if (!slot) {
    return "current slot";
  }

  const day =
    slot.dayName ||
    slot.dayOfWeek ||
    "";

  const start =
    slot.startTime?.slice(0, 5) ||
    "";

  const end =
    slot.endTime?.slice(0, 5) ||
    "";

  return `${day} ${start}–${end}`;
}

function wait(milliseconds) {
  return new Promise(
    (resolve) =>
      setTimeout(
        resolve,
        milliseconds,
      ),
  );
}

async function waitWhilePaused() {
  while (pausedRef.current) {
    await wait(120);
  }
}