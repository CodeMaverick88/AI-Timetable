import { useEffect, useState } from "react";
import {
  AlertTriangle,
  ArrowRight,
  BrainCircuit,
  CheckCircle2,
  RefreshCw,
} from "lucide-react";
import { Link } from "react-router-dom";

import Reveal from "../components/Reveal";
import GlassCard from "../components/GlassCard";
import TimetableBoard from "../components/TimetableBoard";

import {
  getConflicts,
  getTimetable,
} from "../services/api";

export default function Timetable() {
  const [entries, setEntries] = useState([]);
  const [conflicts, setConflicts] =
    useState([]);

  const [loading, setLoading] =
    useState(true);

  const [refreshing, setRefreshing] =
    useState(false);

  const [error, setError] =
    useState("");

  async function load(
    showRefreshing = false,
  ) {
    if (showRefreshing) {
      setRefreshing(true);
    } else {
      setLoading(true);
    }

    setError("");

    try {
      const [
        timetable,
        conflictData,
      ] = await Promise.all([
        getTimetable(),
        getConflicts(),
      ]);

      setEntries(
        timetable.entries || [],
      );

      setConflicts(
        conflictData.conflicts || [],
      );
    } catch (requestError) {
      console.error(requestError);

      setError(
        requestError.message ||
          "Unable to load the timetable.",
      );
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  const conflictCount =
    conflicts.length;

  return (
    <Reveal>
      <div className="page-heading">
        <div>
          <span className="eyebrow-small">
            TIMETABLE
          </span>

          <h1>
            Weekly schedule
          </h1>
        </div>

        <div className="page-heading-actions">
          <Link
            className="button-primary timetable-solve-button"
            to="/solver"
          >
            <BrainCircuit size={16} />
            Solve clashes
            <ArrowRight size={15} />
          </Link>

          <Link
            className="button-secondary"
            to="/conflict-lab"
          >
            Create conflict
          </Link>

          <button
            className="button-secondary"
            type="button"
            onClick={() => load(true)}
            disabled={
              loading || refreshing
            }
          >
            <RefreshCw
              size={15}
              className={
                refreshing
                  ? "refresh-spinning"
                  : ""
              }
            />

            {refreshing
              ? "Refreshing..."
              : "Refresh"}
          </button>
        </div>
      </div>

      {error && (
        <Reveal>
          <div className="page-error">
            <AlertTriangle size={18} />

            <div>
              <strong>
                Timetable unavailable
              </strong>

              <p>{error}</p>
            </div>

            <button
              className="button-secondary"
              type="button"
              onClick={() => load(true)}
            >
              Try again
            </button>
          </div>
        </Reveal>
      )}

      <Reveal delay={0.04}>
        <div className="timetable-status-strip">
          <div className="timetable-status-item">
            <div className="status-calendar-icon">
              <span />
              <span />
              <span />
              <span />
            </div>

            <div>
              <strong>
                {loading
                  ? "—"
                  : entries.length}
              </strong>

              <span>
                Classes
              </span>
            </div>
          </div>

          <div className="timetable-status-item">
            {conflictCount > 0 ? (
              <AlertTriangle size={18} />
            ) : (
              <CheckCircle2 size={18} />
            )}

            <div>
              <strong>
                {loading
                  ? "—"
                  : conflictCount}
              </strong>

              <span>
                Conflicts
              </span>
            </div>
          </div>

          <div className="timetable-status-item">
            {conflictCount > 0 ? (
              <BrainCircuit size={18} />
            ) : (
              <CheckCircle2 size={18} />
            )}

            <div>
              <strong>
                {loading
                  ? "—"
                  : conflictCount > 0
                    ? "Needs solving"
                    : "Clear"}
              </strong>

              <span>
                Schedule state
              </span>
            </div>
          </div>
        </div>
      </Reveal>

      <Reveal delay={0.08}>
        <GlassCard className="full-timetable">
          <div className="section-header">
            <div>
              <span className="eyebrow-small">
                WEEKLY BOARD
              </span>

              <h2>
                Current timetable
              </h2>
            </div>

            <div className="board-note">
              {conflictCount > 0 ? (
                <>
                  <AlertTriangle size={14} />

                  {conflictCount} conflict
                  {conflictCount === 1
                    ? ""
                    : "s"} detected
                </>
              ) : (
                <>
                  <CheckCircle2 size={14} />
                  No active conflicts
                </>
              )}
            </div>
          </div>

          <TimetableBoard
            entries={entries}
            loading={loading}
          />
        </GlassCard>
      </Reveal>
    </Reveal>
  );
}

