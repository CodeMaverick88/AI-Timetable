import { useEffect, useState } from "react";
import {
  AlertTriangle,
  ArrowRight,
  BrainCircuit,
  CheckCircle2,
  RefreshCw,
} from "lucide-react";
import { Link } from "react-router-dom";

import GlassCard from "../components/GlassCard";
import Reveal from "../components/Reveal";
import TimetableBoard from "../components/TimetableBoard";

import {
  getConflicts,
  getTimetable,
} from "../services/api";

export default function Home() {
  const [entries, setEntries] = useState([]);
  const [conflicts, setConflicts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] =
    useState(false);

  async function loadDashboard(
    showRefresh = false,
  ) {
    if (showRefresh) {
      setRefreshing(true);
    } else {
      setLoading(true);
    }

    try {
      const [
        timetable,
        conflictData,
      ] = await Promise.all([
        getTimetable(),
        getConflicts(),
      ]);

      setEntries(
        timetable.entries || [],
      );

      setConflicts(
        conflictData.conflicts || [],
      );
    } catch (error) {
      console.error(
        "Failed to load dashboard:",
        error,
      );
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  useEffect(() => {
    loadDashboard();
  }, []);

  const conflictCount =
    conflicts.length;

  return (
    <div className="home">
      <Reveal>
        <div className="page-heading">
          <div>
            <span className="eyebrow-small">
              SMART TIMETABLE
            </span>

            <h1>
              Weekly schedule
            </h1>
          </div>

          <div className="page-heading-actions">
            <Link
              className="button-primary"
              to="/solver"
            >
              <BrainCircuit size={16} />
              Solve clashes
              <ArrowRight size={15} />
            </Link>

            <Link
              className="button-secondary"
              to="/conflict-lab"
            >
              Create conflict
            </Link>
          </div>
        </div>
      </Reveal>

      <Reveal delay={0.04}>
        <div className="timetable-status-strip">
          <div className="timetable-status-item">
            <div className="status-calendar-icon">
              <span />
              <span />
              <span />
              <span />
            </div>

            <div>
              <strong>
                {loading
                  ? "—"
                  : entries.length}
              </strong>

              <span>
                Classes
              </span>
            </div>
          </div>

          <div className="timetable-status-item">
            {conflictCount > 0 ? (
              <AlertTriangle size={18} />
            ) : (
              <CheckCircle2 size={18} />
            )}

            <div>
              <strong>
                {loading
                  ? "—"
                  : conflictCount}
              </strong>

              <span>
                Conflicts
              </span>
            </div>
          </div>

          <div className="timetable-status-item">
            {conflictCount > 0 ? (
              <BrainCircuit size={18} />
            ) : (
              <CheckCircle2 size={18} />
            )}

            <div>
              <strong>
                {loading
                  ? "—"
                  : conflictCount > 0
                    ? "ORBIT ready"
                    : "Schedule clear"}
              </strong>

              <span>
                Status
              </span>
            </div>
          </div>

          <button
            className="button-secondary"
            type="button"
            onClick={() =>
              loadDashboard(true)
            }
            disabled={refreshing}
          >
            <RefreshCw
              size={15}
              className={
                refreshing
                  ? "refresh-spinning"
                  : ""
              }
            />

            Refresh
          </button>
        </div>
      </Reveal>

      <Reveal delay={0.08}>
        <GlassCard className="full-timetable">
          <div className="section-header">
            <div>
              <span className="eyebrow-small">
                LIVE BOARD
              </span>

              <h2>
                Current timetable
              </h2>
            </div>

            <div className="board-note">
              {conflictCount > 0 ? (
                <>
                  <AlertTriangle size={14} />

                  {conflictCount} conflict
                  {conflictCount === 1
                    ? ""
                    : "s"}
                </>
              ) : (
                <>
                  <CheckCircle2 size={14} />
                  Clear
                </>
              )}
            </div>
          </div>

          <TimetableBoard
            entries={entries}
            loading={loading}
          />
        </GlassCard>
      </Reveal>

      <Reveal delay={0.12}>
        <div className="home-bottom">
          <div>
            <span className="eyebrow-small">
              ORBIT
            </span>

            <h2>
              {conflictCount > 0
                ? "Conflicts detected."
                : "Ready to test a conflict."}
            </h2>

            <p>
              {conflictCount > 0
                ? "Run ORBIT to resolve the current timetable."
                : "Create a timetable clash and watch ORBIT resolve it."}
            </p>
          </div>

          <Link
            className="button-primary"
            to={
              conflictCount > 0
                ? "/solver"
                : "/conflict-lab"
            }
          >
            {conflictCount > 0
              ? "Solve with ORBIT"
              : "Create conflict"}

            <ArrowRight size={16} />
          </Link>
        </div>
      </Reveal>
    </div>
  );
}

